# inventario_backend/app/routers/__init__.py
# Archivo vacío
