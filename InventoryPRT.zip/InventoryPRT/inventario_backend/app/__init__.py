# inventario_backend/app/__init__.py
# Archivo vacío